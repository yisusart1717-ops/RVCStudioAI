package com.rvcstudioai.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 8, 7)
    private val panel = Color.rgb(14, 24, 20)
    private val neon = Color.rgb(0, 245, 122)
    private var songUri: Uri? = null
    private var modelUri: Uri? = null
    private lateinit var songLabel: TextView
    private lateinit var modelLabel: TextView
    private lateinit var modeGroup: RadioGroup
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(18))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(TextView(this).apply {
            text = "〽  RVC STUDIO AI"
            textSize = 27f; setTextColor(neon); gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(4)); typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        content.addView(TextView(this).apply {
            text = "COVERS CON INTELIGENCIA ARTIFICIAL"
            textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        })
        section(content, "1 · CANCIÓN")
        songLabel = label("Todavía no elegiste una canción")
        content.addView(songLabel)
        content.addView(button("Elegir canción (audio)") { pickSong() })

        section(content, "2 · MODELO RVC")
        modelLabel = label("Importá un modelo .pth y, si tenés, su .index")
        content.addView(modelLabel)
        content.addView(button("Importar modelo .pth") { pickModel("pth") })
        content.addView(button("Importar índice .index (opcional)") { pickModel("index") })

        section(content, "3 · PROCESAMIENTO")
        modeGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val local = RadioButton(this).apply { text = "Local · en el teléfono (requiere motor compatible)"; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(neon) }
        val online = RadioButton(this).apply { text = "Online · mediante servidor RVC"; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(neon) }
        modeGroup.addView(local); modeGroup.addView(online); online.isChecked = true
        content.addView(modeGroup)

        section(content, "4 · AJUSTES DE VOZ")
        slider(content, "Pitch / transposición", -12, 12, 0)
        slider(content, "Index Rate", 0, 100, 75)
        slider(content, "Protect", 0, 100, 33)
        val server = EditText(this).apply {
            hint = "URL de tu servidor RVC (p. ej. https://...)"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize = 14f
            setSingleLine(true); setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(panel)
        }
        content.addView(server)
        section(content, "RESULTADO")
        status = label("Listo para configurar. La conversión todavía requiere conectar un motor RVC.")
        content.addView(status)
        content.addView(button("Preparar cover") {
            val missing = when {
                songUri == null -> "Elegí primero una canción."
                modelUri == null -> "Importá primero un modelo .pth."
                modeGroup.checkedRadioButtonId == -1 -> "Elegí un modo de procesamiento."
                else -> "Archivos seleccionados. Para convertir audio, conectá un servidor RVC o integrá un motor local compatible. Esta versión inicial aún no ejecuta la conversión."
            }
            status.text = missing
        })
        content.addView(TextView(this).apply {
            text = "Nota: usá modelos de voz y audios que tengas derecho a utilizar. Los archivos se seleccionan desde el almacenamiento de Android."
            textSize = 11f; setTextColor(Color.GRAY); setPadding(0, dp(18), 0, dp(10))
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title; textSize = 15f; setTextColor(neon); typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(8))
        })
    }
    private fun label(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 13f; setTextColor(Color.WHITE); setPadding(dp(12), dp(12), dp(12), dp(12)); setBackgroundColor(panel)
    }
    private fun button(title: String, action: () -> Unit) = Button(this).apply {
        text = title; setTextColor(Color.BLACK); backgroundTintList = android.content.res.ColorStateList.valueOf(neon)
        isAllCaps = false; setOnClickListener { action() }
    }
    private fun slider(parent: LinearLayout, title: String, min: Int, max: Int, initial: Int) {
        val line = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
        val caption = TextView(this).apply { text = "$title: $initial"; setTextColor(Color.WHITE); textSize = 13f }
        val seek = SeekBar(this).apply { this.max = max - min; progress = initial - min; progressTintList = android.content.res.ColorStateList.valueOf(neon); thumbTintList = android.content.res.ColorStateList.valueOf(neon) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) { caption.text = "$title: ${progress + min}" }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        line.addView(caption); line.addView(seek); parent.addView(line)
    }
    private fun pickSong() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*" }
        startActivityForResult(i, 10)
    }
    private fun pickModel(ext: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, if (ext == "pth") arrayOf("application/octet-stream", "application/x-pytorch") else arrayOf("application/octet-stream", "application/octet-stream"))
        }
        startActivityForResult(i, if (ext == "pth") 11 else 12)
    }
    @Deprecated("Deprecated by Android API; kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            10 -> { songUri = uri; songLabel.text = "Canción seleccionada:\n${uri.lastPathSegment ?: uri}" }
            11 -> { modelUri = uri; modelLabel.text = "Modelo .pth seleccionado:\n${uri.lastPathSegment ?: uri}" }
            12 -> { modelLabel.text = modelLabel.text.toString() + "\nÍndice .index seleccionado: ${uri.lastPathSegment ?: uri}" }
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
